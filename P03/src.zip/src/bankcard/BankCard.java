package bankcard;

import java.math.BigDecimal;

/**
 * Created by ets on 20.09.17.
 */
public interface BankCard {
    public final int paymentPrecision = 4;
    public BigDecimal getAccountBalance();
    public void makePayment(BigDecimal paymentAmount);
}
