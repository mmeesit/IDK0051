package coffeegrinder;

public class GrinderNotCleanException extends Exception {
    public GrinderNotCleanException(String msg) {
        super(msg);
    }
}
