import robot.FightingRobot;

public class RobotFight {
    public static void main(String[] args) {
        FightingRobot optimusPrime = new FightingRobot();
        optimusPrime.setName("Optimus Prime");

        System.out.println(optimusPrime.robotInfo());

        optimusPrime.getRobotEngine().changeSpeed(10);
    }
}
