package strategy;

public interface Strategy {
    int move();
}
