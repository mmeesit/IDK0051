package strategy;

public class DefenceStrategy implements Strategy {
    @Override
    public int move() {
        return 0;
    }
}
