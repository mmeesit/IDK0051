package strategy;

public class AttackStrategy implements Strategy {
    @Override
    public int move() {
        return 0;
    }
}
