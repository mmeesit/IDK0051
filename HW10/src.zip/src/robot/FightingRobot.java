package robot;

import engine.Engine;
import engine.RobotEngine;

public class FightingRobot implements Robot {
    private String name;
    private RobotEngine robotEngine;

    public FightingRobot() {
        this.robotEngine = new RobotEngine();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public RobotEngine getRobotEngine() {
        return robotEngine;
    }

    @Override
    public void beingAttacked(int opponentHeight, int opponentSpeed) {

    }

    @Override
    public void opponentRetreats(int retreatSpeed) {

    }

    @Override
    public void inDeadlock() {

    }

    @Override
    public String robotInfo() {
        return "Name: " + getName();
    }
}
