package engine;

public interface Engine {
    void changeSpeed(int speed);
}
