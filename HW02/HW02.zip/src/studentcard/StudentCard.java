package studentcard;

import java.math.BigInteger;

/**
 * Created by ets on 13.09.17.
 */
public interface StudentCard {
    public boolean isStudent(String idFirstDigit, String school);
}
